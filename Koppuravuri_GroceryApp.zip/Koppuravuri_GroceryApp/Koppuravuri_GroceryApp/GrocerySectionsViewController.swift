//
//  ViewController.swift
//  Koppuravuri_GroceryApp
//
//  Created by Koppuravuri,Pavan Kumar on 4/5/22.
//

import UIKit

class GrocerySectionsViewController: UIViewController {

    
    @IBOutlet weak var grocerySectionsTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

