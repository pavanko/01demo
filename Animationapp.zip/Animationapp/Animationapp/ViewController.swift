//
//  ViewController.swift
//  Animationapp
//
//  Created by Koppuravuri,Pavan Kumar on 3/15/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageOutlet: UIImageView!
    
    @IBOutlet weak var happybutton: UIButton!
    
    @IBOutlet weak var sadbutton: UIButton!
    
    @IBOutlet weak var angrybutton: UIButton!
    
    @IBOutlet weak var shakebutton: UIButton!
    
    @IBOutlet weak var showbutton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
    }
    override func viewDidAppear(_ animated: Bool) {
        // Moving all the components outside of the screen.
        imageOutlet.frame.origin.x = view.frame.width;
        happybutton.frame.origin.x = view.frame.width;
        sadbutton.frame.origin.x = view.frame.width;
        angrybutton.frame.origin.x = view.frame.width;
        shakebutton.frame.origin.x = view.frame.width;
        
    }
    
    @IBAction func sadbuttonclicked(_ sender: UIButton) {
        animateimage("sad")
    }
    @IBAction func angrybuttonclicked(_ sender: UIButton) {
        animateimage("Angry")
    }
    @IBAction func shakemebuttonclicked(_ sender: UIButton) {
        var w = imageOutlet.frame.width
        w += 40
        var h = imageOutlet.frame.height
        h += 40
        var x = imageOutlet.frame.origin.x
        x -= 20
        var y = imageOutlet.frame.origin.y
        y -= 20
        
        var largeframe = CGRect(x: x, y: y, width: w, height: h)
        UIView.animate(withDuration: 1, delay: 0,usingSpringWithDamping: 0.2, initialSpringVelocity: 0, animations: {
            self.imageOutlet.frame = largeframe
        })
    }
    @IBAction func showbuttonclicked(_ sender: UIButton) {
        
        UIView.animate(withDuration: 1, animations: {
            // bring all the components to the center of the screen.
            self.imageOutlet.center.x = self.view.center.x
            self.happybutton.center.x = self.view.center.x
            self.sadbutton.center.x = self.view.center.x
            self.angrybutton.center.x = self.view.center.x
            self.shakebutton.center.x = self.view.center.x
            self.showbutton.isEnabled = false
            
        })
       
    }
    @IBAction func happybuttonclicked(_ sender: UIButton) {
        animateimage("Happy")
    }
   
    func animateimage(_ imname: String){
        
        UIView.animate(withDuration: 1, animations:{
            self.imageOutlet.alpha = 0
            
        })
        UIView.animate(withDuration: 1, delay: 0.2, animations: {
            self.imageOutlet.alpha = 1
            self.imageOutlet.image = UIImage(named: imname)
        })
        
        
    }
    
    
}

