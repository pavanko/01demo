//
//  ViewController.swift
//  Animationapp
//
//  Created by Koppuravuri,Pavan Kumar on 3/15/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var happybutton: UIButton!
    
    @IBOutlet weak var sadbutton: UIButton!
    
    @IBOutlet weak var angrybutton: UIButton!
    
    @IBOutlet weak var shakebutton: UIButton!
    
    @IBOutlet weak var showbutton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func happyclicked(_ sender: Any) {
         animateImage("Happy")
    }
    
    @IBAction func sadclicked(_ sender: Any) {
        animateImage("sad")
    }
    
    @IBAction func angry(_ sender: Any) {
        animateImage("Angry")
    }
    
    @IBAction func shakeclicked(_ sender: Any) {
        
    }
    func animateImage(_imageName: String){
        
    }
}

