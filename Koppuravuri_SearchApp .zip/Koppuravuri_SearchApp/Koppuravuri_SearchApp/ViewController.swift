//
//  ViewController.swift
//  Koppuravuri_SearchApp
//
//  Created by Koppuravuri,Pavan Kumar on 3/3/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
       
       
        @IBOutlet weak var resultImage: UIImageView!
       
        @IBOutlet weak var topicInfoText: UITextView!
       
        @IBOutlet weak var searchButton: UIButton!
       
       
        @IBOutlet weak var previousButton: UIButton!
       
        @IBOutlet weak var nextButton: UIButton!
       
       
        @IBOutlet weak var resetButton: UIButton!
       
       
        var imageNum = 0;
            var topic: Int = -1
            var count : Int = -1
            var listOfArrays = [["dosa","biriyani","icecream","panipuri","burger"],
                                ["goa","araku","pondicherry","newyork","chicago"],["iphone","iwatch","airpods","ipad","macbook"]]
       
        var food_keywords = ["food"]
       
        var places_keywords = ["places"]
        
    var gadgets_keywords = ["gadgets","apple"]
       
       
       
        var topics_discription = [["Dosa is a popular South Indian thin crepe made with fermented rice and lentil batter.","Biryani is a mixed rice dish originating among the Muslims of the Indian subcontinent. It is made with Indian spices, rice, either with meat (chicken, beef, goat, lamb, prawn, fish), or eggs or vegetables such as potatoes.","ice cream, frozen dairy food made from cream or butterfat, milk, sugar, and flavourings. Frozen custard and French-type ice creams also contain eggs","Burger is famous fast food in foreign countries", "panipuri is famous street food in india"],["Araku is located in the Eastern Ghats about 114 kilometres (71 mi) from Visakhapatnam, close to the Odisha state border. The Anantagiri and Sunkarimetta Reserved Forest, which are part of Araku Valley, are rich in biodiversity and are mined for bauxite.[2] Galikonda hill rising to a height of 5,000 feet (1,500 m) is amongst the highest peaks in Andhra Pradesh. The average rainfall is 1,700 millimetres (67 in), the bulk of which is received during June–October.[3] The altitude is about 1300 m above the sea level. The valley spreads around 36 km.[4]","Puducherry, original name Putucceri, formerly (until 2006) Pondicherry, also spelled Pondichéry, union territory of India. It was formed in 1962 out of the four former colonies of French India: Pondicherry (now Puducherry) and Karaikal along India’s southeastern Coromandel Coast, surrounded by Tamil Nadu state; Yanam, farther north along the eastern coast in the delta region of the Godavari River, surrounded by Andhra Pradesh state; and Mahe, lying on the western Malabar Coast, surrounded by Kerala state. The territory’s capital is the city of Puducherry in the Puducherry sector, just north of Cuddalore.","Goa, state of India, comprising a mainland district on the country’s southwestern coast and an offshore island. It is located about 250 miles (400 km) south of Mumbai (Bombay). One of India’s smallest states, it is bounded by the states of Maharashtra on the north and Karnataka on the east and south and by the Arabian Sea on the west. The capital is Panaji (Panjim), on the north-central coast of the mainland district. Formerly a Portuguese possession, it became a part of India in 1962 and attained statehood in 1987. Area 1,429 square miles (3,702 square km). Pop. (2011) 1,457,723.","New york is famous tourist place in US","Chicago records the coldest temperatures"],
                                  ["All apple products are very user friendly","All apple products are very user friendly","All apple products are very user friendly","All apple products are very user friendly","All apple products are very user friendly"]]
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            searchButton.isEnabled = false
            previousButton.isHidden = true
            nextButton.isHidden = true
            resetButton.isHidden = true
            resultImage.image = UIImage(named: "default")
        }


        @IBAction func searchButtonAction(_ sender: UIButton) {
            if(food_keywords.contains(searchTextField.text!)){
                topic = 0
                imageNum = 0
                buttonsDisable()
            }
            else if(places_keywords.contains(searchTextField.text!)){
                topic = 1
                imageNum = 0
                buttonsDisable()
            }
            else if(gadgets_keywords.contains(searchTextField.text!)){
                topic = 2
                imageNum = 0
                buttonsDisable()
            }
            else{
                topic = -1
                resultImage.image = UIImage(named: "searchNotFound")
                topicInfoText.text = "No matches found with the given Keywords."
                resetButton.isHidden = true
                nextButton.isHidden = true
                previousButton.isHidden = true
            }
           
            if(topic != -1)
            {
                previousButton.isEnabled = false
                nextButton.isEnabled = true
                count = listOfArrays[topic].count
                resultImage.image = UIImage(named: listOfArrays[topic][0])
                topicInfoText.text = topics_discription[topic][0]
            }

        }
       
        @IBAction func showNextImagesBtn(_ sender: UIButton) {
            previousButton.isEnabled = true
            imageNum += 1
            resultImage.image = UIImage(named: listOfArrays[topic][imageNum])
            topicInfoText.text = topics_discription[topic][imageNum]
                        if(imageNum == count-1){
                            nextButton.isEnabled = false
                        }

        }
       
        @IBAction func showPrevImagesBtn(_ sender: UIButton) {
            nextButton.isEnabled = true;
                        imageNum -= 1
                        resultImage.image = UIImage(named: listOfArrays[topic][imageNum])
                        topicInfoText.text = topics_discription[topic][imageNum]
                        if(imageNum == 0){
                                    previousButton.isEnabled = false
                            }

        }
       
    
    @IBAction func searchTextFieldChanged(_ sender: UITextField) {
        searchButton.isEnabled = true
    }
    
        
       
        @IBAction func resetButtonClicked(_ sender: UIButton) {
           
                    nextButton.isHidden = true
                    previousButton.isHidden = true
                    resetButton.isHidden = true
                    searchTextField.text = ""
                    searchButton.isEnabled = false
                    topicInfoText.text = ""
                    resultImage.image = UIImage(named: "searchNotFound")
                   

        }
       
        func buttonsDisable(){
                nextButton.isHidden = false
                previousButton.isHidden = false
                resetButton.isHidden = false
            }

    }






