//
//  ViewController.swift
//  Koppuravuri_SearchApp
//
//  Created by Koppuravuri,Pavan Kumar on 3/3/22.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var searchoption: UIButton!
    
    @IBOutlet weak var resultimage: UIImageView!
    
    @IBOutlet weak var previmg: UIButton!
    
    @IBOutlet weak var nextimg: UIButton!
    
    @IBOutlet weak var topicinfotext: UITextView!
    
    @IBOutlet weak var resetbutton: UIButton!
    
    var imageNumber = 0;
    var topic: Int = -1
    var count1 : Int = -1
    var arr = [
               ["dosa","biriyani","icecream"],
               ["araku","pondicherry","goa"]]
               var food_keywords = ["indian","food","taste"]
               var places_keywords = ["distance","places","modeoftravel"]
    
    
    
    
    
    
    
    
    var topic_array = [["Dosa is a popular South Indian thin crepe made with fermented rice and lentil batter.","Biryani is a mixed rice dish originating among the Muslims of the Indian subcontinent. It is made with Indian spices, rice, either with meat (chicken, beef, goat, lamb, prawn, fish), or eggs or vegetables such as potatoes.","ice cream, frozen dairy food made from cream or butterfat, milk, sugar, and flavourings. Frozen custard and French-type ice creams also contain eggs"],["Araku is located in the Eastern Ghats about 114 kilometres (71 mi) from Visakhapatnam, close to the Odisha state border. The Anantagiri and Sunkarimetta Reserved Forest, which are part of Araku Valley, are rich in biodiversity and are mined for bauxite.[2] Galikonda hill rising to a height of 5,000 feet (1,500 m) is amongst the highest peaks in Andhra Pradesh. The average rainfall is 1,700 millimetres (67 in), the bulk of which is received during June–October.[3] The altitude is about 1300 m above the sea level. The valley spreads around 36 km.[4]","Puducherry, original name Putucceri, formerly (until 2006) Pondicherry, also spelled Pondichéry, union territory of India. It was formed in 1962 out of the four former colonies of French India: Pondicherry (now Puducherry) and Karaikal along India’s southeastern Coromandel Coast, surrounded by Tamil Nadu state; Yanam, farther north along the eastern coast in the delta region of the Godavari River, surrounded by Andhra Pradesh state; and Mahe, lying on the western Malabar Coast, surrounded by Kerala state. The territory’s capital is the city of Puducherry in the Puducherry sector, just north of Cuddalore.","Goa, state of India, comprising a mainland district on the country’s southwestern coast and an offshore island. It is located about 250 miles (400 km) south of Mumbai (Bombay). One of India’s smallest states, it is bounded by the states of Maharashtra on the north and Karnataka on the east and south and by the Arabian Sea on the west. The capital is Panaji (Panjim), on the north-central coast of the mainland district. Formerly a Portuguese possession, it became a part of India in 1962 and attained statehood in 1987. Area 1,429 square miles (3,702 square km). Pop. (2011) 1,457,723."]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        searchoption.isEnabled = false
        nextimg.isHidden = true
        previmg.isHidden = true
        resetbutton.isHidden = true
        resultimage.image = UIImage(named: "default")

    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        if(food_keywords.contains(searchTextField.text!)){
            topic = 0
            imageNumber = 0
            buttonsDisable()
        }
        else if(places_keywords.contains(searchTextField.text!)){
            topic = 1
            imageNumber = 0
            buttonsDisable()
        }
        
        else{
            topic = -1
            resultimage.image = UIImage(named: "default")
            topicinfotext.text = "No matches with the given Key words. Please try again."
            resetbutton.isHidden = true
            nextimg.isHidden = true
            previmg.isHidden = true
        }
        
        if(topic != -1)
        {
            previmg.isEnabled = false
            nextimg.isEnabled = true
            count1 = arr[topic].count
            resultimage.image = UIImage(named: arr[topic][0])
            topicinfotext.text = topic_array[topic][0]
        }
        
    }



    @IBAction func searchtextaction(_ sender: UITextField) {
        searchoption.isEnabled = true
    }
    
    
    
    @IBAction func previmgaction(_ sender: UIButton) {
        
        nextimg.isEnabled = true;
        imageNumber -= 1
        resultimage.image = UIImage(named: arr[topic][imageNumber])
        topicinfotext.text = topic_array[topic][imageNumber]
        if(imageNumber == 0){
                    previmg.isEnabled = false
            }
    }
    
    
    @IBAction func nextimgaction(_ sender: UIButton) {
        
        previmg.isEnabled = true
        imageNumber += 1
        resultimage.image = UIImage(named: arr[topic][imageNumber])
        topicinfotext.text = topic_array[topic][imageNumber]
        if(imageNumber == count1-1){
            nextimg.isEnabled = false
        }
    }
    
    
    
    
    @IBAction func resetaction(_ sender: UIButton) {
        
        nextimg.isHidden = true
        previmg.isHidden = true
        resetbutton.isHidden = true
        searchTextField.text = ""
        searchoption.isEnabled = false
        topicinfotext.text = ""
        resultimage.image = UIImage(named: "default")
    }
    
    
func buttonsDisable(){
    nextimg.isHidden = false
    previmg.isHidden = false
    resetbutton.isHidden = false
}

}

    


